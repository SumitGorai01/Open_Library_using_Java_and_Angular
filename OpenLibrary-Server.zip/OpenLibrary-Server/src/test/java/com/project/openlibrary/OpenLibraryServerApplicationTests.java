package com.project.openlibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenLibraryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
