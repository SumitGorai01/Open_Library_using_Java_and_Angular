import { Component } from '@angular/core';

@Component({
  selector: 'app-computer-book',
  templateUrl: './computer-book.component.html',
  styleUrl: './computer-book.component.css'
})
export class ComputerBookComponent {

}
