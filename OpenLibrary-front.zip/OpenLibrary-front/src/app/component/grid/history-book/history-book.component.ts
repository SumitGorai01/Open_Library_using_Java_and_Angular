import { Component } from '@angular/core';

@Component({
  selector: 'app-history-book',
  templateUrl: './history-book.component.html',
  styleUrl: './history-book.component.css'
})
export class HistoryBookComponent {

}
