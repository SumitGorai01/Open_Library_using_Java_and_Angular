import { Component } from '@angular/core';

@Component({
  selector: 'app-vedas-book',
  templateUrl: './vedas-book.component.html',
  styleUrl: './vedas-book.component.css'
})
export class VedasBookComponent {

}
