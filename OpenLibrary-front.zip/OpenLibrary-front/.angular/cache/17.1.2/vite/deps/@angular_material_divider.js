import {
  MatDivider,
  MatDividerModule
} from "./chunk-BK3R6NNI.js";
import "./chunk-WFH3JKVJ.js";
import "./chunk-GMMRJ2CZ.js";
import "./chunk-SYQQ6VOZ.js";
import "./chunk-JPN5AOHM.js";
import "./chunk-2JNEIYKB.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-WKYGNSYM.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
